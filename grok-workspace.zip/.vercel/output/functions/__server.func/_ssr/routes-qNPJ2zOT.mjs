import { i as __toESM } from "../_runtime.mjs";
import { G as require_react, K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Hexagon, c as Database, i as Radio, l as Cpu, n as Shield, o as GitBranch, r as Settings, s as Gauge, u as Boxes } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-qNPJ2zOT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Card({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `rounded-card border border-line bg-surface p-4 ${className}`,
		children
	});
}
function Eyebrow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-medium tracking-widest text-muted uppercase",
		children
	});
}
function Field({ label, value, onChange, placeholder, mono = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			placeholder,
			onChange: (event) => onChange(event.target.value),
			className: `w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm text-fg outline-none placeholder:text-faint focus:border-signal ${mono ? "font-mono" : ""}`
		})]
	});
}
function PrimaryButton({ children, onClick, type = "button", disabled = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: "inline-flex min-h-11 items-center justify-center rounded-lg bg-signal px-4 py-2 text-sm font-semibold text-signal-ink transition hover:brightness-110 disabled:opacity-40",
		children
	});
}
function GhostButton({ children, onClick, disabled = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		onClick,
		className: "inline-flex min-h-11 items-center justify-center rounded-lg border border-line bg-raised px-4 py-2 text-sm text-fg transition hover:border-signal disabled:opacity-40",
		children
	});
}
function StatusDot({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-block size-2 rounded-full ${status === "healthy" ? "bg-signal" : status === "starting" ? "bg-amber" : "bg-faint"}`,
		"aria-hidden": true
	});
}
var BUDGET_MB = 16384;
var SERVICES = [
	{
		id: "postgres",
		name: "PostgreSQL 16",
		port: "5432",
		mem: 512,
		cpu: "1.0",
		role: "Shared store · assist_os + assist_kernel",
		profile: "core"
	},
	{
		id: "redis",
		name: "Redis 7",
		port: "6379",
		mem: 256,
		cpu: "0.5",
		role: "Event bus and durable queue",
		profile: "core"
	},
	{
		id: "foundation",
		name: "Foundation",
		port: "8800",
		mem: 256,
		cpu: "0.5",
		role: "OpenAI-compatible assistai server",
		profile: "core"
	},
	{
		id: "backend",
		name: "Backend API",
		port: "8000",
		mem: 512,
		cpu: "1.0",
		role: "Hardened 21-router suite",
		profile: "core"
	},
	{
		id: "kernel",
		name: "Self-Operating Kernel",
		port: "8001",
		mem: 512,
		cpu: "1.0",
		role: "Policy, tools, OpenAI shim",
		profile: "core"
	},
	{
		id: "worker",
		name: "Kernel worker",
		port: "internal",
		mem: 256,
		cpu: "0.5",
		role: "app.workers.runner",
		profile: "workers"
	},
	{
		id: "webui",
		name: "Open WebUI",
		port: "3000",
		mem: 1536,
		cpu: "1.0",
		role: "Chat connected to kernel /v1",
		profile: "ui"
	},
	{
		id: "ollama",
		name: "Ollama",
		port: "11434",
		mem: 5120,
		cpu: "host",
		role: "qwen2.5-coder local models",
		profile: "ollama"
	}
];
var PROVIDERS = [
	{
		id: "ollama",
		name: "Ollama local",
		model: "qwen2.5-coder:7b",
		quota: "Always-on · zero cost",
		active: true,
		local: true
	},
	{
		id: "groq",
		name: "Groq",
		model: "llama-3.3-70b-versatile",
		quota: "30 RPM · 14.4K TPM",
		active: false
	},
	{
		id: "gemini",
		name: "Gemini",
		model: "gemini-2.5-flash",
		quota: "15 RPM · 1,500 req/day",
		active: false
	},
	{
		id: "cerebras",
		name: "Cerebras",
		model: "llama-3.3-70b",
		quota: "30 RPM · 1M tokens/day",
		active: false
	},
	{
		id: "github",
		name: "GitHub Models",
		model: "gpt-4o",
		quota: "15 RPM developer tier",
		active: false
	},
	{
		id: "nvidia",
		name: "NVIDIA NIM",
		model: "llama-3.1-70b-instruct",
		quota: "Developer credits",
		active: false
	},
	{
		id: "openrouter",
		name: "OpenRouter",
		model: "llama-3.2-3b-instruct:free",
		quota: "200 RPM free models",
		active: false
	},
	{
		id: "mistral",
		name: "Mistral",
		model: "codestral-latest",
		quota: "1 RPS free tier",
		active: false
	},
	{
		id: "cohere",
		name: "Cohere",
		model: "command-r-plus",
		quota: "Trial key",
		active: false
	},
	{
		id: "cloudflare",
		name: "Cloudflare Workers AI",
		model: "llama-3.1-8b",
		quota: "10,000 neurons/day",
		active: false
	},
	{
		id: "huggingface",
		name: "Hugging Face",
		model: "Qwen2.5-72B-Instruct",
		quota: "Serverless inference",
		active: false
	},
	{
		id: "llm7",
		name: "LLM7 gateway",
		model: "multi-model",
		quota: "No-card free endpoints",
		active: false
	}
];
var SEED_MEMORIES = [
	{
		id: "mem-foundation",
		title: "Foundation routing",
		body: "Nothing above ModelRouter talks to a backend directly. Default is Ollama at :11434, model qwen2.5-coder:7b, with an optional OpenAI-compatible fallback.",
		collection: "foundation",
		tags: "router ollama memory.json"
	},
	{
		id: "mem-guard",
		title: "ExecutionGuard",
		body: "Every agent action is Agent → ExecutionGuard → BrowserOS. Governance is never bypassed. POST /governance/check uses the JWT role, not the role in the body.",
		collection: "sprint-a",
		tags: "governance event-bus"
	},
	{
		id: "mem-terminal",
		title: "Terminal allowlist",
		body: "Workflow terminal is admin-only and limited to ls, pwd, echo, df, free, ps, uptime, whoami, uname. Path traversal and absolute paths outside the root are blocked.",
		collection: "security",
		tags: "rbac vault"
	},
	{
		id: "mem-budget",
		title: "16 GB workstation budget",
		body: "Core stack is PostgreSQL 512M, Redis 256M, Foundation 256M, Backend 512M, Kernel 512M. Optional profiles: workers 256M, Open WebUI 1536M, Ollama 5G.",
		collection: "ops",
		tags: "compose memory"
	},
	{
		id: "mem-vault",
		title: "Sealed vault",
		body: "SecretVault stores v1:nonce:ciphertext:tag using PBKDF2-HMAC-SHA256, a random nonce, and an HMAC. Vault and audit routes require an admin.",
		collection: "security",
		tags: "vault hmac"
	}
];
var COLLECTIONS = [
	"foundation",
	"sprint-a",
	"security",
	"ops",
	"lab"
];
function selectedServices(profiles) {
	return SERVICES.filter((service) => {
		if (service.profile === "core") return true;
		return profiles[service.profile];
	});
}
function budgetOf(ids) {
	return SERVICES.filter((service) => ids.includes(service.id)).reduce((sum, service) => sum + service.mem, 0);
}
function bestProvider(providers) {
	return providers.find((provider) => provider.active) ?? null;
}
function stamp(date = /* @__PURE__ */ new Date()) {
	return date.toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
var DIAG = [
	"ls",
	"pwd",
	"echo",
	"df",
	"free",
	"ps",
	"uptime",
	"whoami",
	"uname"
];
function govern(text) {
	const raw = text.trim();
	if (/(?:\.\.\/|\/etc\/|~\/)/.test(raw)) return {
		verdict: "DENY",
		reason: "Path leaves the workstation root. Traversal is blocked."
	};
	if (/\b(vault master|jwt secret|print (the )?secrets?|dump (the )?vault)\b/i.test(raw)) return {
		verdict: "DENY",
		reason: "SecretVault is sealed. Vault and audit routes stay admin-gated and never echo key material."
	};
	if (/^\s*(?:\$\s*)?(sudo|rm|curl|wget|python3?|pip3?|git|chmod|chown|bash|sh|nc|nmap|mkfs|dd)\b/i.test(raw)) return {
		verdict: "DENY",
		reason: `Terminal allowlist is read-only: ${DIAG.join(", ")}.`
	};
	return {
		verdict: "ALLOW",
		reason: "ExecutionGuard passed. The signed operator role was used, not a role sent in the body."
	};
}
function runDiagnostic(command) {
	const trimmed = command.trim().replace(/^\$\s*/, "");
	const [bin, ...rest] = trimmed.split(/\s+/);
	if (!bin) return {
		ok: false,
		lines: ["empty command"]
	};
	if (/(?:\.\.|\/etc\/)/.test(trimmed)) return {
		ok: false,
		lines: ["DENY  path escapes /app"]
	};
	if (!DIAG.includes(bin)) return {
		ok: false,
		lines: [`DENY  '${bin}' is not on the admin allowlist`, `allow  ${DIAG.join(" ")}`]
	};
	return {
		ok: true,
		lines: [{
			ls: "app  data  pyproject.toml  README.md",
			pwd: "/app",
			echo: rest.join(" ") || "",
			df: "Filesystem   Size  Used  Avail  Mount\noverlay      16G   2.1G  13G    /data",
			free: "Mem: 16384  2048  14336",
			ps: "1 uvicorn app.main\n2 redis-server\n3 postgres",
			uptime: "up 12 min, load average: 0.18 0.11 0.08",
			whoami: "assist",
			uname: "Linux assist-kernel 6.8.0 x86_64"
		}[bin] ?? ""]
	};
}
function citeMemories(query, notes) {
	const terms = query.toLowerCase().split(/[^a-z0-9]+/).filter((term) => term.length > 3);
	return notes.map((note) => {
		const hay = `${note.title} ${note.body} ${note.tags} ${note.collection}`.toLowerCase();
		return {
			note,
			score: terms.reduce((sum, term) => sum + (hay.includes(term) ? 1 : 0), 0)
		};
	}).filter((hit) => hit.score > 0).sort((a, b) => b.score - a.score).slice(0, 3).map((hit) => hit.note);
}
function composeAnswer(prompt, notes, providers, model) {
	const gate = govern(prompt);
	const provider = bestProvider(providers);
	if (gate.verdict === "DENY") return {
		verdict: gate.verdict,
		reason: gate.reason,
		provider: provider?.id ?? "none",
		cites: [],
		text: `${gate.reason}\n\nThe action was not dispatched. Team Brain will log the denial.`
	};
	if (!provider) return {
		verdict: "ALLOW",
		reason: gate.reason,
		provider: "none",
		cites: [],
		text: "No provider is armed. Toggle at least one endpoint on the Providers desk. Ollama stays the default so the workstation can answer with the network dark."
	};
	const cites = citeMemories(prompt, notes);
	const lower = prompt.toLowerCase();
	let body;
	if (/\b(budget|memory|ram|16 ?gb|compose)\b/.test(lower)) body = "Core footprint is 2,048 MB: Postgres 512, Redis 256, Foundation 256, Backend 512, Kernel 512. Workers, Open WebUI, and Ollama are profiles, not part of the always-on set. The ceiling on this workstation is 16,384 MB. Bring the stack up from the Stack desk before expecting /health on :8800, :8000, or :8001.";
	else if (/\b(provider|failover|ollama|groq|model)\b/.test(lower)) body = `ModelRouter selected ${provider.name} (${provider.model}). Configured default tag is ${model}. Fallback order follows the armed list, top to bottom. Callers above the router never see which endpoint answered.`;
	else if (/\b(govern|guard|rbac|role|jwt)\b/.test(lower)) body = "Sprint A order is fixed: Browser OS, then Governance, then the event bus, then knowledge and Team Brain. Operational routers require an authenticated operator. Admin routers — policies, vault, audit, the workflow terminal — require admin. The check endpoint ignores agent_role in the JSON body.";
	else if (cites.length > 0) body = cites.map((note) => note.body).join("\n\n");
	else body = `Kernel accepted the task on ${provider.name}. With no matching memory hit, this stays a plan rather than a fabricated lookup: decompose on the supervisor, keep tools inside the allowlist, and write the result back to the lab collection if it should survive the session.`;
	const citeLine = cites.length > 0 ? `\n\nCited from memory: ${cites.map((note) => note.title).join(", ")}.` : "";
	return {
		verdict: "ALLOW",
		reason: gate.reason,
		provider: provider.id,
		cites: cites.map((note) => note.title),
		text: `${body}${citeLine}\n\nProvider ${provider.id} · model ${provider.local ? model : provider.model}.`
	};
}
function supervisorScript(goal) {
	return [
		`supervisor  goal="${goal}"`,
		"planner    streams B/H · subtasks researcher, coder, system",
		"researcher pulled sprint-a notes · governance order confirmed",
		"coder      patch confined to /app · sandbox isolated",
		"verify     smoke /health and /v1/models · PASS",
		"event      AGENT_TASK_COMPLETED · team_brain"
	];
}
function scrapeScript(url) {
	let host = url;
	try {
		host = new URL(url).host;
	} catch {
		return ["DENY  target is not an absolute http(s) URL"];
	}
	return [
		`browser    session created · guard ALLOW`,
		`fetch      ${host} · dry-run, no live socket`,
		"extract    title, headings, outbound links",
		"event      BrowserSessionCreated → knowledge pipeline stage 1",
		"done       7-stage pipeline would publish from here when the backend is attached"
	];
}
var downStatus = () => Object.fromEntries(SERVICES.map((service) => [service.id, "down"]));
var timers = /* @__PURE__ */ new Set();
function clearTimers() {
	timers.forEach((id) => window.clearTimeout(id));
	timers.clear();
}
function later(fn, ms) {
	const id = window.setTimeout(() => {
		timers.delete(id);
		fn();
	}, ms);
	timers.add(id);
}
function pushLog(logs, line) {
	return [...logs, `${stamp()}  ${line}`].slice(-80);
}
function pushEvent(events, event) {
	return [{
		id: uid("ev"),
		ts: stamp(),
		...event
	}, ...events].slice(0, 40);
}
var seedDecisions = () => [{
	id: "dec-budget",
	agent: "ArchitectureAuditor",
	summary: "Locked the always-on set to the 2 GB core so a 16 GB workstation can still host Ollama.",
	ts: "boot"
}, {
	id: "dec-router",
	agent: "ModelRouter",
	summary: "Armed Ollama first. Cloud providers stay dark until an operator toggles them.",
	ts: "boot"
}];
var initial = () => ({
	view: "stack",
	moreOpen: false,
	profiles: {
		workers: false,
		ui: false,
		ollama: true
	},
	status: downStatus(),
	logs: ["console attached · stack halted · profiles remembered"],
	notice: null,
	providers: PROVIDERS,
	messages: [],
	drafting: false,
	memories: SEED_MEMORIES,
	events: [],
	decisions: seedDecisions(),
	jobs: [],
	settings: {
		operator: "operator",
		model: "qwen2.5-coder:7b",
		remediation: false
	},
	governFlash: null
});
var useOs = create()(persist((set, get) => ({
	...initial(),
	setView: (view) => set({
		view,
		moreOpen: false
	}),
	setMore: (moreOpen) => set({ moreOpen }),
	toggleProfile: (profile) => set((state) => ({
		profiles: {
			...state.profiles,
			[profile]: !state.profiles[profile]
		},
		notice: "Profile saved. It applies the next time you bring the stack up."
	})),
	bringUp: () => {
		clearTimers();
		const profiles = get().profiles;
		const chosen = selectedServices(profiles);
		const mem = chosen.reduce((sum, service) => sum + service.mem, 0);
		if (mem > 16384) {
			set({ notice: `Refused. ${mem} MB is over the ${BUDGET_MB} MB workstation ceiling.` });
			return;
		}
		const status = downStatus();
		chosen.forEach((service) => {
			status[service.id] = "starting";
		});
		set((state) => ({
			status,
			notice: null,
			logs: pushLog(state.logs, `compose up · ${chosen.map((service) => service.id).join(", ")} · ${mem} MB`),
			events: pushEvent(state.events, {
				type: "SYSTEM_HEALTH_CHANGED",
				src: "compose",
				detail: `starting ${chosen.length} services`
			})
		}));
		chosen.forEach((service, index) => {
			later(() => {
				set((state) => ({
					status: {
						...state.status,
						[service.id]: "healthy"
					},
					logs: pushLog(state.logs, `${service.name} healthy · :${service.port}`),
					events: pushEvent(state.events, {
						type: "SYSTEM_HEALTH_CHANGED",
						src: service.id,
						detail: `${service.name} ready`
					})
				}));
			}, 280 + index * 320);
		});
	},
	halt: () => {
		clearTimers();
		set((state) => ({
			status: downStatus(),
			notice: null,
			logs: pushLog(state.logs, "compose down · volumes kept"),
			events: pushEvent(state.events, {
				type: "SYSTEM_HEALTH_CHANGED",
				src: "compose",
				detail: "stack halted"
			})
		}));
	},
	toggleProvider: (id) => set((state) => {
		const providers = state.providers.map((provider) => provider.id === id ? {
			...provider,
			active: !provider.active
		} : provider);
		const best = bestProvider(providers);
		return {
			providers,
			notice: `best_provider → ${best ? best.id : "none"}`,
			events: pushEvent(state.events, {
				type: "PROVIDER_SET_CHANGED",
				src: "registry",
				detail: best ? `${best.id} is first armed` : "no provider armed"
			})
		};
	}),
	send: (text) => {
		const trimmed = text.trim();
		if (!trimmed || get().drafting) return;
		const foundation = get().status.foundation;
		const operator = {
			id: uid("op"),
			role: "operator",
			text: trimmed
		};
		if (foundation !== "healthy") {
			const kernel = {
				id: uid("k"),
				role: "kernel",
				text: "Foundation is not healthy. Bring the core stack up on the Stack desk, then ask again. Port 8800 is the OpenAI-compatible front door.",
				verdict: "DENY"
			};
			set((state) => ({ messages: [
				...state.messages,
				operator,
				kernel
			].slice(-40) }));
			return;
		}
		set((state) => ({
			messages: [...state.messages, operator].slice(-40),
			drafting: true
		}));
		const answer = composeAnswer(trimmed, get().memories, get().providers, get().settings.model);
		later(() => {
			const kernel = {
				id: uid("k"),
				role: "kernel",
				text: answer.text,
				provider: answer.provider,
				verdict: answer.verdict,
				cites: answer.cites
			};
			const decision = {
				id: uid("dec"),
				agent: answer.verdict === "DENY" ? "ExecutionGuard" : "ModelRouter",
				summary: answer.verdict === "DENY" ? answer.reason : `Answered via ${answer.provider}. ${answer.reason}`,
				ts: stamp()
			};
			set((state) => ({
				drafting: false,
				messages: [...state.messages, kernel].slice(-40),
				decisions: [decision, ...state.decisions].slice(0, 24),
				events: pushEvent(state.events, {
					type: answer.verdict === "DENY" ? "ACTION_DENIED" : "AGENT_TASK_COMPLETED",
					src: "kernel",
					detail: answer.verdict === "DENY" ? answer.reason : `provider ${answer.provider}`
				})
			}));
		}, 420);
	},
	addMemory: (note) => set((state) => ({
		memories: [{
			...note,
			id: uid("mem")
		}, ...state.memories],
		events: pushEvent(state.events, {
			type: "MEMORY_WRITTEN",
			src: "memory",
			detail: note.title
		})
	})),
	removeMemory: (id) => set((state) => ({ memories: state.memories.filter((note) => note.id !== id) })),
	runSupervisor: (goal) => {
		const clean = goal.trim();
		if (!clean) return;
		if (get().status.backend !== "healthy") {
			set({ notice: "Backend :8000 is down. Workflows mount on the API suite." });
			return;
		}
		const job = {
			id: uid("job"),
			name: "supervisor",
			status: "running",
			lines: []
		};
		set((state) => ({
			jobs: [job, ...state.jobs].slice(0, 12),
			notice: null
		}));
		supervisorScript(clean).forEach((line, index) => {
			later(() => {
				set((state) => ({ jobs: state.jobs.map((item) => item.id === job.id ? {
					...item,
					lines: [...item.lines, line],
					status: index === supervisorScript(clean).length - 1 ? "done" : "running"
				} : item) }));
			}, 240 + index * 280);
		});
	},
	runScrape: (url) => {
		const clean = url.trim();
		if (get().status.backend !== "healthy") {
			set({ notice: "Backend :8000 is down. The browser adapter lives there." });
			return;
		}
		const gate = govern(`browse ${clean}`);
		const lines = gate.verdict === "DENY" ? [`DENY  ${gate.reason}`] : scrapeScript(clean || "https://example.com");
		const job = {
			id: uid("job"),
			name: "scrape",
			status: gate.verdict === "DENY" ? "denied" : "running",
			lines: []
		};
		set((state) => ({ jobs: [job, ...state.jobs].slice(0, 12) }));
		lines.forEach((line, index) => {
			later(() => {
				set((state) => ({ jobs: state.jobs.map((item) => item.id === job.id ? {
					...item,
					lines: [...item.lines, line],
					status: index === lines.length - 1 ? gate.verdict === "DENY" ? "denied" : "done" : item.status
				} : item) }));
			}, 200 + index * 240);
		});
	},
	runTerminal: (command) => {
		if (get().status.kernel !== "healthy") {
			set({ notice: "Kernel :8001 is down. The terminal adapter is on the self-operating kernel." });
			return;
		}
		const result = runDiagnostic(command);
		const job = {
			id: uid("job"),
			name: "terminal",
			status: result.ok ? "done" : "denied",
			lines: [`$ ${command.trim()}`, ...result.lines]
		};
		set((state) => ({
			jobs: [job, ...state.jobs].slice(0, 12),
			decisions: [{
				id: uid("dec"),
				agent: "TerminalExecutor",
				summary: result.ok ? `Allowlisted ${command.trim()}` : `Blocked ${command.trim()}`,
				ts: stamp()
			}, ...state.decisions].slice(0, 24)
		}));
	},
	governFlash: null,
	checkGovernance: (action) => {
		const clean = action.trim();
		if (!clean) return null;
		const gate = govern(clean);
		const flash = {
			...gate,
			action: clean
		};
		set((state) => ({
			governFlash: flash,
			decisions: [{
				id: uid("dec"),
				agent: "ExecutionGuard",
				summary: `${gate.verdict} · ${clean}`,
				ts: stamp()
			}, ...state.decisions].slice(0, 24),
			events: pushEvent(state.events, {
				type: gate.verdict === "ALLOW" ? "GOVERNANCE_ALLOW" : "ACTION_DENIED",
				src: "governance",
				detail: clean
			})
		}));
		return flash;
	},
	patchSettings: (patch) => set((state) => ({ settings: {
		...state.settings,
		...patch
	} })),
	resetWorkstation: () => {
		clearTimers();
		set({
			...initial(),
			notice: "Workstation reset. Stack is halted."
		});
	}
}), {
	name: "assist-os-v62",
	skipHydration: true,
	partialize: (state) => ({
		view: state.view,
		profiles: state.profiles,
		status: state.status,
		logs: state.logs,
		providers: state.providers,
		messages: state.messages,
		memories: state.memories,
		events: state.events,
		decisions: state.decisions,
		jobs: state.jobs,
		settings: state.settings
	}),
	onRehydrateStorage: () => (state) => {
		if (!state) return;
		const status = { ...state.status };
		Object.keys(status).forEach((id) => {
			if (status[id] === "starting") status[id] = "healthy";
		});
		state.status = status;
	}
}));
function useLiveBudget() {
	const status = useOs((state) => state.status);
	return budgetOf(Object.keys(status).filter((id) => status[id] !== "down"));
}
function Notice() {
	const notice = useOs((state) => state.notice);
	if (!notice) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-4 rounded-lg border border-amber/40 bg-amber-ink px-3 py-2 text-sm text-amber",
		children: notice
	});
}
function StackView() {
	const profiles = useOs((state) => state.profiles);
	const status = useOs((state) => state.status);
	const logs = useOs((state) => state.logs);
	const toggleProfile = useOs((state) => state.toggleProfile);
	const bringUp = useOs((state) => state.bringUp);
	const halt = useOs((state) => state.halt);
	const plannedMb = selectedServices(profiles).reduce((sum, service) => sum + service.mem, 0);
	const liveMb = useLiveBudget();
	const ratio = Math.min(100, Math.round(plannedMb / BUDGET_MB * 100));
	const anyUp = Object.values(status).some((item) => item !== "down");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "docker-compose.minimal.yml" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-semibold tracking-tight",
					children: "Workstation stack"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted",
					children: "Three Python 3.12 suites plus Postgres 16 and Redis 7. This desk models the 16 GB compose: services report health here, they are not containers on this preview."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 md:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Planned footprint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-2xl",
						children: [
							plannedMb.toLocaleString(),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [
									"/ ",
									BUDGET_MB.toLocaleString(),
									" MB"
								]
							})
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm text-signal",
						children: [liveMb.toLocaleString(), " MB live"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-signal",
						style: { width: `${ratio}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: bringUp,
						children: "Bring stack up"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: halt,
						disabled: !anyUp,
						children: "Halt"
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Profiles" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-col gap-2",
				children: [
					[
						"workers",
						"Workers",
						"kernel queue runner"
					],
					[
						"ui",
						"Open WebUI",
						"port 3000"
					],
					[
						"ollama",
						"Ollama",
						"5 GB model cache"
					]
				].map(([id, label, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => toggleProfile(id),
					className: `flex min-h-11 items-center justify-between rounded-lg border px-3 py-2 text-left ${profiles[id] ? "border-signal bg-raised" : "border-line"}`,
					"aria-pressed": profiles[id],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: hint
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-signal",
						children: profiles[id] ? "on" : "off"
					})]
				}, id))
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: service.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: service.role
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 font-mono text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, { status: status[service.id] }), status[service.id]]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-xs text-faint",
				children: [
					":",
					service.port,
					" · ",
					service.mem,
					" MB · cpu ",
					service.cpu,
					" · ",
					service.profile
				]
			})] }, service.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Compose log" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 max-h-56 overflow-auto font-mono text-xs leading-6 text-signal",
				children: logs.map((line) => `› ${line}`).join("\n")
			})]
		})
	] });
}
function CommandView() {
	const status = useOs((state) => state.status);
	const providers = useOs((state) => state.providers);
	const events = useOs((state) => state.events);
	const settings = useOs((state) => state.settings);
	const setView = useOs((state) => state.setView);
	const healthy = Object.values(status).filter((item) => item === "healthy").length;
	const armed = providers.filter((provider) => provider.active).length;
	const best = bestProvider(providers);
	const [Chart, setChart] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		import("./budget-chart-DnhTpm8c.mjs").then((mod) => setChart(() => mod.BudgetChart));
	}, []);
	const rows = (0, import_react.useMemo)(() => SERVICES.filter((service) => status[service.id] !== "down").map((service) => ({
		name: service.id,
		mem: service.mem
	})), [status]);
	const agents = [
		["ExecutionGuard", "Every action passes the guard before BrowserOS."],
		["ModelRouter", best ? `best_provider ${best.id}` : "No provider armed"],
		["Team Brain", "Logs completions from the event bus."],
		["Knowledge", "Seven-stage pipeline, typed events at each stage."]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Command" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold tracking-tight",
				children: "Sovereign desk"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-xs text-muted",
				children: ["model ", settings.model]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				["Healthy", String(healthy)],
				["Armed providers", String(armed)],
				["Bus events", String(events.length)],
				["Best", best?.id ?? "none"]
			].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-2xl",
				children: value
			})] }, label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-[1.3fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Live allocation" }), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-muted",
				children: [
					"Stack is halted.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-signal underline",
						onClick: () => setView("stack"),
						children: "Bring it up"
					}),
					" ",
					"to draw memory against the 16 GB ceiling."
				]
			}) : Chart ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, { rows }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-44" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Agents" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-3",
				children: agents.map(([name, detail]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: detail
				})] }, name))
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Event bus" }), events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Quiet. Health, denials, and memory writes land here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex max-h-64 flex-col gap-2 overflow-auto",
				children: events.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[4.5rem_1fr] gap-3 font-mono text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-faint",
						children: event.ts
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-signal",
						children: event.type
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							" · ",
							event.src,
							" · ",
							event.detail
						]
					})] })]
				}, event.id))
			})]
		})
	] });
}
function LinkView() {
	const messages = useOs((state) => state.messages);
	const drafting = useOs((state) => state.drafting);
	const send = useOs((state) => state.send);
	const [text, setText] = (0, import_react.useState)("");
	const [spoken, setSpoken] = (0, import_react.useState)(null);
	function onSubmit(event) {
		event.preventDefault();
		send(text);
		setText("");
	}
	function speak(id, body) {
		if (typeof window === "undefined" || !window.speechSynthesis) {
			setSpoken("Speech synthesis is not available in this browser.");
			return;
		}
		window.speechSynthesis.cancel();
		const utterance = new SpeechSynthesisUtterance(body.slice(0, 420));
		window.speechSynthesis.speak(utterance);
		setSpoken(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70dvh] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Neural link" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-semibold tracking-tight",
						children: "Kernel chat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Routed through Foundation once it is healthy. Memory hits are cited. The guard still refuses the terminal denylist."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col gap-3",
				children: [
					messages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Try one of these once the stack is up."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							"What is the 16 GB budget?",
							"Which provider answers?",
							"How does the guard treat roles?"
						].map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => send(prompt),
							className: "min-h-11 rounded-lg border border-line px-3 py-2 text-left text-sm hover:border-signal",
							children: prompt
						}, prompt))
					})] }),
					messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `max-w-3xl rounded-card border px-4 py-3 ${message.role === "operator" ? "ml-auto border-line bg-raised" : "border-line bg-surface"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-muted",
								children: message.role === "operator" ? "operator" : `kernel · ${message.provider ?? "offline"} · ${message.verdict ?? ""}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm whitespace-pre-wrap",
								children: message.text
							}),
							message.role === "kernel" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-xs text-signal",
								onClick: () => speak(message.id, message.text),
								children: spoken === message.id ? "Speaking" : "Speak"
							})
						]
					}, message.id)),
					drafting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-signal",
						children: "streaming…"
					})
				]
			}),
			spoken && spoken.length > 12 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-amber",
				children: spoken
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-4 flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "link-input",
						children: "Message the kernel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "link-input",
						value: text,
						onChange: (event) => setText(event.target.value),
						placeholder: "Ask the kernel",
						className: "min-h-11 flex-1 rounded-lg border border-line bg-bg px-3 text-sm outline-none focus:border-signal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						disabled: drafting || text.trim().length === 0,
						children: "Send"
					})
				]
			})
		]
	});
}
function MemoryView() {
	const memories = useOs((state) => state.memories);
	const addMemory = useOs((state) => state.addMemory);
	const removeMemory = useOs((state) => state.removeMemory);
	const [query, setQuery] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [collection, setCollection] = (0, import_react.useState)(COLLECTIONS[4]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const shown = (query.trim() ? citeMemories(query, memories) : memories).filter((note) => filter === "all" || note.collection === filter);
	function onSubmit(event) {
		event.preventDefault();
		if (!title.trim() || !body.trim()) return;
		addMemory({
			title: title.trim(),
			body: body.trim(),
			collection,
			tags: "operator"
		});
		setTitle("");
		setBody("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Memory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold tracking-tight",
				children: "Notes the router can cite"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Search",
			value: query,
			onChange: setQuery,
			placeholder: "guard, vault, budget…"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: ["all", ...COLLECTIONS].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(name),
				className: `min-h-11 rounded-full border px-3 text-sm ${filter === name ? "border-signal text-signal" : "border-line text-muted"}`,
				children: name
			}, name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3",
			children: [shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No notes in this slice."
			}), shown.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: note.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: note.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-faint",
						children: [
							note.collection,
							" · ",
							note.tags
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs text-danger",
					onClick: () => removeMemory(note.id),
					children: "Remove"
				})]
			}) }, note.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "mt-4 grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Write a note" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					value: title,
					onChange: setTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-muted",
						children: "Body"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: body,
						onChange: (event) => setBody(event.target.value),
						rows: 3,
						className: "w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm outline-none focus:border-signal"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-muted",
						children: "Collection"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: collection,
						onChange: (event) => setCollection(event.target.value),
						className: "min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm",
						children: COLLECTIONS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: name }, name))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Store note"
				})
			]
		})
	] });
}
function FlowsView() {
	const jobs = useOs((state) => state.jobs);
	const runSupervisor = useOs((state) => state.runSupervisor);
	const runScrape = useOs((state) => state.runScrape);
	const runTerminal = useOs((state) => state.runTerminal);
	const [goal, setGoal] = (0, import_react.useState)("Harden the provider failover note");
	const [url, setUrl] = (0, import_react.useState)("https://ollama.com");
	const [command, setCommand] = (0, import_react.useState)("uname");
	const notice = useOs((state) => state.notice);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 rounded-lg border border-amber/40 bg-amber-ink px-3 py-2 text-sm text-amber",
			children: notice
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Workflows" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-semibold tracking-tight",
					children: "Supervisor, browser, terminal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted",
					children: "Needs a healthy backend. The terminal stays on the v6.1 allowlist and prints a dry-run, not a live shell."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						runSupervisor(goal);
					},
					className: "flex h-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Supervisor" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Goal",
							value: goal,
							onChange: setGoal
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							children: "Run"
						})
					]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						runScrape(url);
					},
					className: "flex h-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Browser scrape" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "URL",
							value: url,
							onChange: setUrl,
							mono: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							children: "Scrape"
						})
					]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						runTerminal(command);
					},
					className: "flex h-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Admin terminal" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Command",
							value: command,
							onChange: setCommand,
							mono: true,
							placeholder: "ls, df, free…"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							children: "Exec"
						})
					]
				}) })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3",
			children: [jobs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No jobs yet."
			}), jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: job.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `font-mono text-xs ${job.status === "denied" ? "text-danger" : "text-signal"}`,
					children: job.status
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 overflow-auto font-mono text-xs leading-6 text-muted",
				children: job.lines.join("\n")
			})] }, job.id))]
		})
	] });
}
function ProvidersView() {
	const providers = useOs((state) => state.providers);
	const toggleProvider = useOs((state) => state.toggleProvider);
	const best = bestProvider(providers);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Registry" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold tracking-tight",
				children: "Provider multiplexer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 font-mono text-sm text-signal",
				children: ["best_provider: ", best?.id ?? "none"]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => toggleProvider(provider.id),
			"aria-pressed": provider.active,
			className: `rounded-card border p-4 text-left ${provider.active ? "border-signal bg-surface" : "border-line bg-bg"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: provider.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-signal",
						children: provider.active ? "armed" : "dark"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-mono text-xs text-muted",
					children: provider.model
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 block text-sm text-muted",
					children: provider.quota
				})
			]
		}, provider.id))
	})] });
}
function GovernView() {
	const decisions = useOs((state) => state.decisions);
	const flash = useOs((state) => state.governFlash);
	const check = useOs((state) => state.checkGovernance);
	const [action, setAction] = (0, import_react.useState)("ls /app");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Sprint A" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-semibold tracking-tight",
					children: "Governance guard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted",
					children: [
						"Propose an action. The guard uses the operator role already on the session. Try ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: "curl"
						}),
						", a vault dump, or ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: "df"
						}),
						"."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3 sm:flex-row",
			onSubmit: (event) => {
				event.preventDefault();
				check(action);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Proposed action",
					value: action,
					onChange: setAction,
					mono: true
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sm:pt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Check"
				})
			})]
		}),
		flash && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `font-mono text-sm ${flash.verdict === "ALLOW" ? "text-signal" : "text-danger"}`,
				children: flash.verdict
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm",
				children: flash.reason
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Team Brain ledger" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-3",
				children: decisions.map((decision) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium",
					children: [decision.agent, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 font-mono text-xs text-faint",
						children: decision.ts
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: decision.summary
				})] }, decision.id))
			})]
		})
	] });
}
function SettingsView() {
	const settings = useOs((state) => state.settings);
	const patch = useOs((state) => state.patchSettings);
	const reset = useOs((state) => state.resetWorkstation);
	const [armed, setArmed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Settings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-semibold tracking-tight",
					children: "Operator"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Callsign",
						value: settings.operator,
						onChange: (operator) => patch({ operator })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1 block text-xs text-muted",
							children: "Default model tag"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: settings.model,
							onChange: (event) => patch({ model: event.target.value }),
							className: "min-h-11 w-full rounded-lg border border-line bg-bg px-3 font-mono text-sm",
							children: [
								"qwen2.5-coder:7b",
								"qwen2.5-coder:1.5b",
								"nomic-embed-text"
							].map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: model }, model))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": settings.remediation,
						onClick: () => patch({ remediation: !settings.remediation }),
						className: "flex min-h-11 items-center justify-between rounded-lg border border-line px-3 py-2 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm",
							children: "Live remediation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted",
							children: settings.remediation ? "Would call compose when wired." : "Dry-run only, matching the safe default."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-signal",
							children: settings.remediation ? "live" : "dry"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Published ports" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 font-mono text-sm text-muted",
					children: [
						["5432 postgres", "postgres"],
						["6379 redis", "redis"],
						["8800 foundation", "foundation"],
						["8000 backend", "backend"],
						["8001 kernel", "kernel"],
						["3000 open webui", "webui"],
						["11434 ollama", "ollama"]
					].map(([label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: label }, label))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg bg-danger px-4 text-sm font-semibold text-danger-ink",
						onClick: reset,
						children: "Confirm reset"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => setArmed(false),
						children: "Cancel"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: () => setArmed(true),
					children: "Reset workstation"
				})
			})
		]
	});
}
var NAV = [
	{
		id: "stack",
		label: "Stack",
		icon: Boxes
	},
	{
		id: "command",
		label: "Command",
		icon: Gauge
	},
	{
		id: "link",
		label: "Link",
		icon: Radio
	},
	{
		id: "memory",
		label: "Memory",
		icon: Database
	},
	{
		id: "flows",
		label: "Flows",
		icon: GitBranch
	},
	{
		id: "providers",
		label: "Providers",
		icon: Cpu
	},
	{
		id: "govern",
		label: "Guard",
		icon: Shield
	},
	{
		id: "settings",
		label: "Settings",
		icon: Settings
	}
];
var MOBILE = [
	"stack",
	"command",
	"link",
	"memory"
];
function NavButton({ id, label, icon: Icon, compact = false }) {
	const view = useOs((state) => state.view);
	const setView = useOs((state) => state.setView);
	const active = view === id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setView(id),
		"aria-current": active ? "page" : void 0,
		className: `flex min-h-11 items-center gap-3 rounded-lg px-3 py-2 text-sm ${compact ? "flex-col gap-1 px-1 text-xs" : ""} ${active ? "bg-raised text-signal" : "text-muted hover:text-fg"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			size: 18,
			strokeWidth: 1.75,
			"aria-hidden": true
		}), label]
	});
}
function Console() {
	const view = useOs((state) => state.view);
	const moreOpen = useOs((state) => state.moreOpen);
	const setMore = useOs((state) => state.setMore);
	const operator = useOs((state) => state.settings.operator);
	const healthy = useOs((state) => Object.values(state.status).filter((status) => status === "healthy").length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-56 shrink-0 flex-col border-r border-line bg-surface md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 border-b border-line px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, {
							className: "text-signal",
							size: 22,
							strokeWidth: 1.75,
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold tracking-wide",
							children: "ASSIST OS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-faint",
							children: "v6.2 · 16 GB"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1 p-3",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, { ...item }, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border-t border-line px-4 py-3 font-mono text-xs text-faint",
						children: [
							operator,
							" · ",
							healthy,
							" healthy"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between border-b border-line px-4 py-3 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, {
							className: "text-signal",
							size: 18,
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold",
							children: "ASSIST OS"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs text-signal",
						children: [healthy, " up"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 overflow-y-auto px-4 py-5 pb-24 md:px-8 md:pb-8",
					children: [
						view === "stack" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StackView, {}),
						view === "command" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandView, {}),
						view === "link" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkView, {}),
						view === "memory" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryView, {}),
						view === "flows" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowsView, {}),
						view === "providers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProvidersView, {}),
						view === "govern" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GovernView, {}),
						view === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-surface md:hidden",
				children: [MOBILE.map((id) => {
					const item = NAV.find((entry) => entry.id === id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						...item,
						compact: true
					}, id);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `flex min-h-11 flex-col items-center justify-center gap-1 text-xs ${moreOpen ? "text-signal" : "text-muted"}`,
					onClick: () => setMore(!moreOpen),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
						size: 18,
						"aria-hidden": true
					}), "More"]
				})]
			}),
			moreOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 bg-bg/80 md:hidden",
				onClick: () => setMore(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 rounded-t-card border border-line bg-surface p-4 pb-8",
					onClick: (event) => event.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs tracking-widest text-muted uppercase",
						children: "More desks"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: NAV.filter((item) => !MOBILE.includes(item.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, { ...item }, item.id))
					})]
				})
			})
		]
	});
}
function Home() {
	(0, import_react.useEffect)(() => {
		useOs.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, {});
}
//#endregion
export { Home as component };
