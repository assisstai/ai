import {
  Boxes,
  Cpu,
  Database,
  Gauge,
  GitBranch,
  Hexagon,
  Radio,
  Settings,
  Shield,
  type LucideIcon,
} from "lucide-react";
import { CommandView, FlowsView, GovernView, LinkView, MemoryView, ProvidersView, SettingsView, StackView } from "@/components/os/views";
import type { ViewId } from "@/os/model";
import { useOs } from "@/os/store";

const NAV: { id: ViewId; label: string; icon: LucideIcon }[] = [
  { id: "stack", label: "Stack", icon: Boxes },
  { id: "command", label: "Command", icon: Gauge },
  { id: "link", label: "Link", icon: Radio },
  { id: "memory", label: "Memory", icon: Database },
  { id: "flows", label: "Flows", icon: GitBranch },
  { id: "providers", label: "Providers", icon: Cpu },
  { id: "govern", label: "Guard", icon: Shield },
  { id: "settings", label: "Settings", icon: Settings },
];

const MOBILE: ViewId[] = ["stack", "command", "link", "memory"];

function NavButton({
  id,
  label,
  icon: Icon,
  compact = false,
}: {
  id: ViewId;
  label: string;
  icon: LucideIcon;
  compact?: boolean;
}) {
  const view = useOs((state) => state.view);
  const setView = useOs((state) => state.setView);
  const active = view === id;
  return (
    <button
      type="button"
      onClick={() => setView(id)}
      aria-current={active ? "page" : undefined}
      className={`flex min-h-11 items-center gap-3 rounded-lg px-3 py-2 text-sm ${compact ? "flex-col gap-1 px-1 text-xs" : ""} ${active ? "bg-raised text-signal" : "text-muted hover:text-fg"}`}
    >
      <Icon size={18} strokeWidth={1.75} aria-hidden />
      {label}
    </button>
  );
}

export function Console() {
  const view = useOs((state) => state.view);
  const moreOpen = useOs((state) => state.moreOpen);
  const setMore = useOs((state) => state.setMore);
  const operator = useOs((state) => state.settings.operator);
  const healthy = useOs((state) => Object.values(state.status).filter((status) => status === "healthy").length);

  return (
    <div className="flex h-dvh overflow-hidden">
      <aside className="hidden w-56 shrink-0 flex-col border-r border-line bg-surface md:flex">
        <div className="flex items-center gap-2 border-b border-line px-4 py-4">
          <Hexagon className="text-signal" size={22} strokeWidth={1.75} aria-hidden />
          <div>
            <p className="text-sm font-semibold tracking-wide">ASSIST OS</p>
            <p className="font-mono text-xs text-faint">v6.2 · 16 GB</p>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 p-3">
          {NAV.map((item) => (
            <NavButton key={item.id} {...item} />
          ))}
        </nav>
        <p className="border-t border-line px-4 py-3 font-mono text-xs text-faint">
          {operator} · {healthy} healthy
        </p>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-line px-4 py-3 md:hidden">
          <div className="flex items-center gap-2">
            <Hexagon className="text-signal" size={18} aria-hidden />
            <span className="text-sm font-semibold">ASSIST OS</span>
          </div>
          <span className="font-mono text-xs text-signal">{healthy} up</span>
        </header>
        <main className="flex-1 overflow-y-auto px-4 py-5 pb-24 md:px-8 md:pb-8">
          {view === "stack" && <StackView />}
          {view === "command" && <CommandView />}
          {view === "link" && <LinkView />}
          {view === "memory" && <MemoryView />}
          {view === "flows" && <FlowsView />}
          {view === "providers" && <ProvidersView />}
          {view === "govern" && <GovernView />}
          {view === "settings" && <SettingsView />}
        </main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-surface md:hidden">
        {MOBILE.map((id) => {
          const item = NAV.find((entry) => entry.id === id)!;
          return <NavButton key={id} {...item} compact />;
        })}
        <button
          type="button"
          className={`flex min-h-11 flex-col items-center justify-center gap-1 text-xs ${moreOpen ? "text-signal" : "text-muted"}`}
          onClick={() => setMore(!moreOpen)}
        >
          <Settings size={18} aria-hidden />
          More
        </button>
      </nav>
      {moreOpen && (
        <div className="fixed inset-0 z-30 bg-bg/80 md:hidden" onClick={() => setMore(false)}>
          <div
            className="absolute inset-x-0 bottom-0 rounded-t-card border border-line bg-surface p-4 pb-8"
            onClick={(event) => event.stopPropagation()}
          >
            <p className="mb-3 text-xs tracking-widest text-muted uppercase">More desks</p>
            <div className="grid grid-cols-2 gap-2">
              {NAV.filter((item) => !MOBILE.includes(item.id)).map((item) => (
                <NavButton key={item.id} {...item} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
