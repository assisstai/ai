import { useEffect, useMemo, useState, type ComponentType, type FormEvent } from "react";
import { Card, Eyebrow, Field, GhostButton, PrimaryButton, StatusDot } from "@/components/os/bits";
import { BUDGET_MB, COLLECTIONS, SERVICES, bestProvider, selectedServices, type ServiceId } from "@/os/model";
import { citeMemories } from "@/os/kernel";
import { useLiveBudget, useOs } from "@/os/store";

function Notice() {
  const notice = useOs((state) => state.notice);
  if (!notice) return null;
  return <p className="mb-4 rounded-lg border border-amber/40 bg-amber-ink px-3 py-2 text-sm text-amber">{notice}</p>;
}

export function StackView() {
  const profiles = useOs((state) => state.profiles);
  const status = useOs((state) => state.status);
  const logs = useOs((state) => state.logs);
  const toggleProfile = useOs((state) => state.toggleProfile);
  const bringUp = useOs((state) => state.bringUp);
  const halt = useOs((state) => state.halt);
  const planned = selectedServices(profiles);
  const plannedMb = planned.reduce((sum, service) => sum + service.mem, 0);
  const liveMb = useLiveBudget();
  const ratio = Math.min(100, Math.round((plannedMb / BUDGET_MB) * 100));
  const anyUp = Object.values(status).some((item) => item !== "down");

  return (
    <div>
      <Notice />
      <header className="mb-5">
        <Eyebrow>docker-compose.minimal.yml</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Workstation stack</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Three Python 3.12 suites plus Postgres 16 and Redis 7. This desk models the 16 GB compose: services
          report health here, they are not containers on this preview.
        </p>
      </header>
      <div className="mb-4 grid gap-3 md:grid-cols-[1.4fr_1fr]">
        <Card>
          <div className="flex items-end justify-between gap-3">
            <div>
              <Eyebrow>Planned footprint</Eyebrow>
              <p className="mt-1 font-mono text-2xl">
                {plannedMb.toLocaleString()} <span className="text-sm text-muted">/ {BUDGET_MB.toLocaleString()} MB</span>
              </p>
            </div>
            <p className="font-mono text-sm text-signal">{liveMb.toLocaleString()} MB live</p>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-raised">
            <div className="h-full rounded-full bg-signal" style={{ width: `${ratio}%` }} />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <PrimaryButton onClick={bringUp}>Bring stack up</PrimaryButton>
            <GhostButton onClick={halt} disabled={!anyUp}>
              Halt
            </GhostButton>
          </div>
        </Card>
        <Card>
          <Eyebrow>Profiles</Eyebrow>
          <div className="mt-3 flex flex-col gap-2">
            {(
              [
                ["workers", "Workers", "kernel queue runner"],
                ["ui", "Open WebUI", "port 3000"],
                ["ollama", "Ollama", "5 GB model cache"],
              ] as const
            ).map(([id, label, hint]) => (
              <button
                key={id}
                type="button"
                onClick={() => toggleProfile(id)}
                className={`flex min-h-11 items-center justify-between rounded-lg border px-3 py-2 text-left ${profiles[id] ? "border-signal bg-raised" : "border-line"}`}
                aria-pressed={profiles[id]}
              >
                <span>
                  <span className="block text-sm font-medium">{label}</span>
                  <span className="block text-xs text-muted">{hint}</span>
                </span>
                <span className="font-mono text-xs text-signal">{profiles[id] ? "on" : "off"}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {SERVICES.map((service) => (
          <Card key={service.id}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium">{service.name}</p>
                <p className="text-sm text-muted">{service.role}</p>
              </div>
              <span className="inline-flex items-center gap-2 font-mono text-xs text-muted">
                <StatusDot status={status[service.id]} />
                {status[service.id]}
              </span>
            </div>
            <p className="mt-3 font-mono text-xs text-faint">
              :{service.port} · {service.mem} MB · cpu {service.cpu} · {service.profile}
            </p>
          </Card>
        ))}
      </div>
      <Card className="mt-4">
        <Eyebrow>Compose log</Eyebrow>
        <pre className="mt-3 max-h-56 overflow-auto font-mono text-xs leading-6 text-signal">
          {logs.map((line) => `› ${line}`).join("\n")}
        </pre>
      </Card>
    </div>
  );
}

export function CommandView() {
  const status = useOs((state) => state.status);
  const providers = useOs((state) => state.providers);
  const events = useOs((state) => state.events);
  const settings = useOs((state) => state.settings);
  const setView = useOs((state) => state.setView);
  const healthy = Object.values(status).filter((item) => item === "healthy").length;
  const armed = providers.filter((provider) => provider.active).length;
  const best = bestProvider(providers);
  const [Chart, setChart] = useState<ComponentType<{ rows: { name: string; mem: number }[] }> | null>(null);
  useEffect(() => {
    void import("@/components/os/budget-chart").then((mod) => setChart(() => mod.BudgetChart));
  }, []);
  const rows = useMemo(
    () =>
      SERVICES.filter((service) => status[service.id] !== "down").map((service) => ({
        name: service.id,
        mem: service.mem,
      })),
    [status],
  );
  const agents = [
    ["ExecutionGuard", "Every action passes the guard before BrowserOS."],
    ["ModelRouter", best ? `best_provider ${best.id}` : "No provider armed"],
    ["Team Brain", "Logs completions from the event bus."],
    ["Knowledge", "Seven-stage pipeline, typed events at each stage."],
  ];

  return (
    <div>
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <Eyebrow>Command</Eyebrow>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">Sovereign desk</h1>
        </div>
        <p className="font-mono text-xs text-muted">model {settings.model}</p>
      </header>
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ["Healthy", String(healthy)],
          ["Armed providers", String(armed)],
          ["Bus events", String(events.length)],
          ["Best", best?.id ?? "none"],
        ].map(([label, value]) => (
          <Card key={label}>
            <Eyebrow>{label}</Eyebrow>
            <p className="mt-2 font-mono text-2xl">{value}</p>
          </Card>
        ))}
      </div>
      <div className="grid gap-3 lg:grid-cols-[1.3fr_1fr]">
        <Card>
          <Eyebrow>Live allocation</Eyebrow>
          {rows.length === 0 ? (
            <p className="mt-6 text-sm text-muted">
              Stack is halted.{" "}
              <button type="button" className="text-signal underline" onClick={() => setView("stack")}>
                Bring it up
              </button>{" "}
              to draw memory against the 16 GB ceiling.
            </p>
          ) : Chart ? (
            <Chart rows={rows} />
          ) : (
            <div className="h-44" />
          )}
        </Card>
        <Card>
          <Eyebrow>Agents</Eyebrow>
          <ul className="mt-3 flex flex-col gap-3">
            {agents.map(([name, detail]) => (
              <li key={name}>
                <p className="text-sm font-medium">{name}</p>
                <p className="text-sm text-muted">{detail}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
      <Card className="mt-4">
        <Eyebrow>Event bus</Eyebrow>
        {events.length === 0 ? (
          <p className="mt-3 text-sm text-muted">Quiet. Health, denials, and memory writes land here.</p>
        ) : (
          <ul className="mt-3 flex max-h-64 flex-col gap-2 overflow-auto">
            {events.map((event) => (
              <li key={event.id} className="grid grid-cols-[4.5rem_1fr] gap-3 font-mono text-xs">
                <span className="text-faint">{event.ts}</span>
                <span>
                  <span className="text-signal">{event.type}</span>
                  <span className="text-muted"> · {event.src} · {event.detail}</span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

export function LinkView() {
  const messages = useOs((state) => state.messages);
  const drafting = useOs((state) => state.drafting);
  const send = useOs((state) => state.send);
  const [text, setText] = useState("");
  const [spoken, setSpoken] = useState<string | null>(null);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    send(text);
    setText("");
  }

  function speak(id: string, body: string) {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      setSpoken("Speech synthesis is not available in this browser.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(body.slice(0, 420));
    window.speechSynthesis.speak(utterance);
    setSpoken(id);
  }

  return (
    <div className="flex min-h-[70dvh] flex-col">
      <header className="mb-4">
        <Eyebrow>Neural link</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Kernel chat</h1>
        <p className="mt-1 text-sm text-muted">
          Routed through Foundation once it is healthy. Memory hits are cited. The guard still refuses the terminal denylist.
        </p>
      </header>
      <div className="flex flex-1 flex-col gap-3">
        {messages.length === 0 && (
          <Card>
            <p className="text-sm text-muted">Try one of these once the stack is up.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["What is the 16 GB budget?", "Which provider answers?", "How does the guard treat roles?"].map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => send(prompt)}
                  className="min-h-11 rounded-lg border border-line px-3 py-2 text-left text-sm hover:border-signal"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </Card>
        )}
        {messages.map((message) => (
          <article
            key={message.id}
            className={`max-w-3xl rounded-card border px-4 py-3 ${message.role === "operator" ? "ml-auto border-line bg-raised" : "border-line bg-surface"}`}
          >
            <p className="font-mono text-xs text-muted">
              {message.role === "operator" ? "operator" : `kernel · ${message.provider ?? "offline"} · ${message.verdict ?? ""}`}
            </p>
            <p className="mt-1 text-sm whitespace-pre-wrap">{message.text}</p>
            {message.role === "kernel" && (
              <button type="button" className="mt-2 text-xs text-signal" onClick={() => speak(message.id, message.text)}>
                {spoken === message.id ? "Speaking" : "Speak"}
              </button>
            )}
          </article>
        ))}
        {drafting && <p className="font-mono text-xs text-signal">streaming…</p>}
      </div>
      {spoken && spoken.length > 12 && <p className="mt-2 text-xs text-amber">{spoken}</p>}
      <form onSubmit={onSubmit} className="mt-4 flex gap-2">
        <label className="sr-only" htmlFor="link-input">
          Message the kernel
        </label>
        <input
          id="link-input"
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder="Ask the kernel"
          className="min-h-11 flex-1 rounded-lg border border-line bg-bg px-3 text-sm outline-none focus:border-signal"
        />
        <PrimaryButton type="submit" disabled={drafting || text.trim().length === 0}>
          Send
        </PrimaryButton>
      </form>
    </div>
  );
}

export function MemoryView() {
  const memories = useOs((state) => state.memories);
  const addMemory = useOs((state) => state.addMemory);
  const removeMemory = useOs((state) => state.removeMemory);
  const [query, setQuery] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [collection, setCollection] = useState<string>(COLLECTIONS[4]);
  const [filter, setFilter] = useState("all");
  const hits = query.trim() ? citeMemories(query, memories) : memories;
  const shown = hits.filter((note) => filter === "all" || note.collection === filter);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!title.trim() || !body.trim()) return;
    addMemory({ title: title.trim(), body: body.trim(), collection, tags: "operator" });
    setTitle("");
    setBody("");
  }

  return (
    <div>
      <header className="mb-5">
        <Eyebrow>Memory</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Notes the router can cite</h1>
      </header>
      <Field label="Search" value={query} onChange={setQuery} placeholder="guard, vault, budget…" />
      <div className="mt-3 flex flex-wrap gap-2">
        {["all", ...COLLECTIONS].map((name) => (
          <button
            key={name}
            type="button"
            onClick={() => setFilter(name)}
            className={`min-h-11 rounded-full border px-3 text-sm ${filter === name ? "border-signal text-signal" : "border-line text-muted"}`}
          >
            {name}
          </button>
        ))}
      </div>
      <div className="mt-4 grid gap-3">
        {shown.length === 0 && <p className="text-sm text-muted">No notes in this slice.</p>}
        {shown.map((note) => (
          <Card key={note.id}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium">{note.title}</p>
                <p className="mt-1 text-sm text-muted">{note.body}</p>
                <p className="mt-2 font-mono text-xs text-faint">
                  {note.collection} · {note.tags}
                </p>
              </div>
              <button type="button" className="text-xs text-danger" onClick={() => removeMemory(note.id)}>
                Remove
              </button>
            </div>
          </Card>
        ))}
      </div>
      <form onSubmit={onSubmit} className="mt-4 grid gap-3">
        <Eyebrow>Write a note</Eyebrow>
        <Field label="Title" value={title} onChange={setTitle} />
        <label className="block">
          <span className="mb-1 block text-xs text-muted">Body</span>
          <textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            rows={3}
            className="w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm outline-none focus:border-signal"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-xs text-muted">Collection</span>
          <select
            value={collection}
            onChange={(event) => setCollection(event.target.value)}
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm"
          >
            {COLLECTIONS.map((name) => (
              <option key={name}>{name}</option>
            ))}
          </select>
        </label>
        <PrimaryButton type="submit">Store note</PrimaryButton>
      </form>
    </div>
  );
}

export function FlowsView() {
  const jobs = useOs((state) => state.jobs);
  const runSupervisor = useOs((state) => state.runSupervisor);
  const runScrape = useOs((state) => state.runScrape);
  const runTerminal = useOs((state) => state.runTerminal);
  const [goal, setGoal] = useState("Harden the provider failover note");
  const [url, setUrl] = useState("https://ollama.com");
  const [command, setCommand] = useState("uname");
  const notice = useOs((state) => state.notice);

  return (
    <div>
      {notice && <p className="mb-4 rounded-lg border border-amber/40 bg-amber-ink px-3 py-2 text-sm text-amber">{notice}</p>}
      <header className="mb-5">
        <Eyebrow>Workflows</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Supervisor, browser, terminal</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Needs a healthy backend. The terminal stays on the v6.1 allowlist and prints a dry-run, not a live shell.
        </p>
      </header>
      <div className="grid gap-3 lg:grid-cols-3">
        <Card>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              runSupervisor(goal);
            }}
            className="flex h-full flex-col gap-3"
          >
            <Eyebrow>Supervisor</Eyebrow>
            <Field label="Goal" value={goal} onChange={setGoal} />
            <PrimaryButton type="submit">Run</PrimaryButton>
          </form>
        </Card>
        <Card>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              runScrape(url);
            }}
            className="flex h-full flex-col gap-3"
          >
            <Eyebrow>Browser scrape</Eyebrow>
            <Field label="URL" value={url} onChange={setUrl} mono />
            <PrimaryButton type="submit">Scrape</PrimaryButton>
          </form>
        </Card>
        <Card>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              runTerminal(command);
            }}
            className="flex h-full flex-col gap-3"
          >
            <Eyebrow>Admin terminal</Eyebrow>
            <Field label="Command" value={command} onChange={setCommand} mono placeholder="ls, df, free…" />
            <PrimaryButton type="submit">Exec</PrimaryButton>
          </form>
        </Card>
      </div>
      <div className="mt-4 grid gap-3">
        {jobs.length === 0 && <p className="text-sm text-muted">No jobs yet.</p>}
        {jobs.map((job) => (
          <Card key={job.id}>
            <div className="flex items-center justify-between">
              <p className="font-medium">{job.name}</p>
              <span className={`font-mono text-xs ${job.status === "denied" ? "text-danger" : "text-signal"}`}>{job.status}</span>
            </div>
            <pre className="mt-2 overflow-auto font-mono text-xs leading-6 text-muted">{job.lines.join("\n")}</pre>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function ProvidersView() {
  const providers = useOs((state) => state.providers);
  const toggleProvider = useOs((state) => state.toggleProvider);
  const best = bestProvider(providers);
  return (
    <div>
      <header className="mb-5">
        <Eyebrow>Registry</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Provider multiplexer</h1>
        <p className="mt-1 font-mono text-sm text-signal">best_provider: {best?.id ?? "none"}</p>
      </header>
      <div className="grid gap-3 sm:grid-cols-2">
        {providers.map((provider) => (
          <button
            key={provider.id}
            type="button"
            onClick={() => toggleProvider(provider.id)}
            aria-pressed={provider.active}
            className={`rounded-card border p-4 text-left ${provider.active ? "border-signal bg-surface" : "border-line bg-bg"}`}
          >
            <span className="flex items-center justify-between gap-2">
              <span className="font-medium">{provider.name}</span>
              <span className="font-mono text-xs text-signal">{provider.active ? "armed" : "dark"}</span>
            </span>
            <span className="mt-1 block font-mono text-xs text-muted">{provider.model}</span>
            <span className="mt-2 block text-sm text-muted">{provider.quota}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function GovernView() {
  const decisions = useOs((state) => state.decisions);
  const flash = useOs((state) => state.governFlash);
  const check = useOs((state) => state.checkGovernance);
  const [action, setAction] = useState("ls /app");

  return (
    <div>
      <header className="mb-5">
        <Eyebrow>Sprint A</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Governance guard</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Propose an action. The guard uses the operator role already on the session. Try <span className="font-mono">curl</span>, a
          vault dump, or <span className="font-mono">df</span>.
        </p>
      </header>
      <form
        className="flex flex-col gap-3 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          check(action);
        }}
      >
        <div className="flex-1">
          <Field label="Proposed action" value={action} onChange={setAction} mono />
        </div>
        <div className="sm:pt-5">
          <PrimaryButton type="submit">Check</PrimaryButton>
        </div>
      </form>
      {flash && (
        <Card className="mt-4">
          <p className={`font-mono text-sm ${flash.verdict === "ALLOW" ? "text-signal" : "text-danger"}`}>{flash.verdict}</p>
          <p className="mt-1 text-sm">{flash.reason}</p>
        </Card>
      )}
      <Card className="mt-4">
        <Eyebrow>Team Brain ledger</Eyebrow>
        <ul className="mt-3 flex flex-col gap-3">
          {decisions.map((decision) => (
            <li key={decision.id}>
              <p className="text-sm font-medium">
                {decision.agent}
                <span className="ml-2 font-mono text-xs text-faint">{decision.ts}</span>
              </p>
              <p className="text-sm text-muted">{decision.summary}</p>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

export function SettingsView() {
  const settings = useOs((state) => state.settings);
  const patch = useOs((state) => state.patchSettings);
  const reset = useOs((state) => state.resetWorkstation);
  const [armed, setArmed] = useState(false);
  const ports: [string, ServiceId][] = [
    ["5432 postgres", "postgres"],
    ["6379 redis", "redis"],
    ["8800 foundation", "foundation"],
    ["8000 backend", "backend"],
    ["8001 kernel", "kernel"],
    ["3000 open webui", "webui"],
    ["11434 ollama", "ollama"],
  ];

  return (
    <div className="max-w-xl">
      <header className="mb-5">
        <Eyebrow>Settings</Eyebrow>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Operator</h1>
      </header>
      <div className="grid gap-3">
        <Field label="Callsign" value={settings.operator} onChange={(operator) => patch({ operator })} />
        <label className="block">
          <span className="mb-1 block text-xs text-muted">Default model tag</span>
          <select
            value={settings.model}
            onChange={(event) => patch({ model: event.target.value })}
            className="min-h-11 w-full rounded-lg border border-line bg-bg px-3 font-mono text-sm"
          >
            {["qwen2.5-coder:7b", "qwen2.5-coder:1.5b", "nomic-embed-text"].map((model) => (
              <option key={model}>{model}</option>
            ))}
          </select>
        </label>
        <button
          type="button"
          aria-pressed={settings.remediation}
          onClick={() => patch({ remediation: !settings.remediation })}
          className="flex min-h-11 items-center justify-between rounded-lg border border-line px-3 py-2 text-left"
        >
          <span>
            <span className="block text-sm">Live remediation</span>
            <span className="block text-xs text-muted">
              {settings.remediation ? "Would call compose when wired." : "Dry-run only, matching the safe default."}
            </span>
          </span>
          <span className="font-mono text-xs text-signal">{settings.remediation ? "live" : "dry"}</span>
        </button>
      </div>
      <Card className="mt-4">
        <Eyebrow>Published ports</Eyebrow>
        <ul className="mt-2 font-mono text-sm text-muted">
          {ports.map(([label]) => (
            <li key={label}>{label}</li>
          ))}
        </ul>
      </Card>
      <div className="mt-4">
        {armed ? (
          <div className="flex gap-2">
            <button type="button" className="min-h-11 rounded-lg bg-danger px-4 text-sm font-semibold text-danger-ink" onClick={reset}>
              Confirm reset
            </button>
            <GhostButton onClick={() => setArmed(false)}>Cancel</GhostButton>
          </div>
        ) : (
          <GhostButton onClick={() => setArmed(true)}>Reset workstation</GhostButton>
        )}
      </div>
    </div>
  );
}
