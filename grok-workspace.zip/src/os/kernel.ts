import type { MemoryNote, Provider } from "@/os/model";
import { bestProvider } from "@/os/model";

const DIAG = ["ls", "pwd", "echo", "df", "free", "ps", "uptime", "whoami", "uname"] as const;

export type GovernResult = { verdict: "ALLOW" | "DENY"; reason: string };

export function govern(text: string): GovernResult {
  const raw = text.trim();
  if (/(?:\.\.\/|\/etc\/|~\/)/.test(raw)) {
    return { verdict: "DENY", reason: "Path leaves the workstation root. Traversal is blocked." };
  }
  if (/\b(vault master|jwt secret|print (the )?secrets?|dump (the )?vault)\b/i.test(raw)) {
    return {
      verdict: "DENY",
      reason: "SecretVault is sealed. Vault and audit routes stay admin-gated and never echo key material.",
    };
  }
  if (/^\s*(?:\$\s*)?(sudo|rm|curl|wget|python3?|pip3?|git|chmod|chown|bash|sh|nc|nmap|mkfs|dd)\b/i.test(raw)) {
    return {
      verdict: "DENY",
      reason: `Terminal allowlist is read-only: ${DIAG.join(", ")}.`,
    };
  }
  return {
    verdict: "ALLOW",
    reason: "ExecutionGuard passed. The signed operator role was used, not a role sent in the body.",
  };
}

export function runDiagnostic(command: string): { ok: boolean; lines: string[] } {
  const trimmed = command.trim().replace(/^\$\s*/, "");
  const [bin, ...rest] = trimmed.split(/\s+/);
  if (!bin) return { ok: false, lines: ["empty command"] };
  if (/(?:\.\.|\/etc\/)/.test(trimmed)) {
    return { ok: false, lines: ["DENY  path escapes /app"] };
  }
  if (!DIAG.includes(bin as (typeof DIAG)[number])) {
    return { ok: false, lines: [`DENY  '${bin}' is not on the admin allowlist`, `allow  ${DIAG.join(" ")}`] };
  }
  const table: Record<string, string> = {
    ls: "app  data  pyproject.toml  README.md",
    pwd: "/app",
    echo: rest.join(" ") || "",
    df: "Filesystem   Size  Used  Avail  Mount\noverlay      16G   2.1G  13G    /data",
    free: "Mem: 16384  2048  14336",
    ps: "1 uvicorn app.main\n2 redis-server\n3 postgres",
    uptime: "up 12 min, load average: 0.18 0.11 0.08",
    whoami: "assist",
    uname: "Linux assist-kernel 6.8.0 x86_64",
  };
  return { ok: true, lines: [table[bin] ?? ""] };
}

export function citeMemories(query: string, notes: MemoryNote[]) {
  const terms = query
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((term) => term.length > 3);
  return notes
    .map((note) => {
      const hay = `${note.title} ${note.body} ${note.tags} ${note.collection}`.toLowerCase();
      const score = terms.reduce((sum, term) => sum + (hay.includes(term) ? 1 : 0), 0);
      return { note, score };
    })
    .filter((hit) => hit.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((hit) => hit.note);
}

export function composeAnswer(prompt: string, notes: MemoryNote[], providers: Provider[], model: string) {
  const gate = govern(prompt);
  const provider = bestProvider(providers);
  if (gate.verdict === "DENY") {
    return {
      verdict: gate.verdict,
      reason: gate.reason,
      provider: provider?.id ?? "none",
      cites: [] as string[],
      text: `${gate.reason}\n\nThe action was not dispatched. Team Brain will log the denial.`,
    };
  }
  if (!provider) {
    return {
      verdict: "ALLOW" as const,
      reason: gate.reason,
      provider: "none",
      cites: [] as string[],
      text: "No provider is armed. Toggle at least one endpoint on the Providers desk. Ollama stays the default so the workstation can answer with the network dark.",
    };
  }
  const cites = citeMemories(prompt, notes);
  const lower = prompt.toLowerCase();
  let body: string;
  if (/\b(budget|memory|ram|16 ?gb|compose)\b/.test(lower)) {
    body =
      "Core footprint is 2,048 MB: Postgres 512, Redis 256, Foundation 256, Backend 512, Kernel 512. Workers, Open WebUI, and Ollama are profiles, not part of the always-on set. The ceiling on this workstation is 16,384 MB. Bring the stack up from the Stack desk before expecting /health on :8800, :8000, or :8001.";
  } else if (/\b(provider|failover|ollama|groq|model)\b/.test(lower)) {
    body = `ModelRouter selected ${provider.name} (${provider.model}). Configured default tag is ${model}. Fallback order follows the armed list, top to bottom. Callers above the router never see which endpoint answered.`;
  } else if (/\b(govern|guard|rbac|role|jwt)\b/.test(lower)) {
    body =
      "Sprint A order is fixed: Browser OS, then Governance, then the event bus, then knowledge and Team Brain. Operational routers require an authenticated operator. Admin routers — policies, vault, audit, the workflow terminal — require admin. The check endpoint ignores agent_role in the JSON body.";
  } else if (cites.length > 0) {
    body = cites.map((note) => note.body).join("\n\n");
  } else {
    body = `Kernel accepted the task on ${provider.name}. With no matching memory hit, this stays a plan rather than a fabricated lookup: decompose on the supervisor, keep tools inside the allowlist, and write the result back to the lab collection if it should survive the session.`;
  }
  const citeLine =
    cites.length > 0 ? `\n\nCited from memory: ${cites.map((note) => note.title).join(", ")}.` : "";
  return {
    verdict: "ALLOW" as const,
    reason: gate.reason,
    provider: provider.id,
    cites: cites.map((note) => note.title),
    text: `${body}${citeLine}\n\nProvider ${provider.id} · model ${provider.local ? model : provider.model}.`,
  };
}

export function supervisorScript(goal: string) {
  return [
    `supervisor  goal="${goal}"`,
    "planner    streams B/H · subtasks researcher, coder, system",
    "researcher pulled sprint-a notes · governance order confirmed",
    "coder      patch confined to /app · sandbox isolated",
    "verify     smoke /health and /v1/models · PASS",
    "event      AGENT_TASK_COMPLETED · team_brain",
  ];
}

export function scrapeScript(url: string) {
  let host = url;
  try {
    host = new URL(url).host;
  } catch {
    return ["DENY  target is not an absolute http(s) URL"];
  }
  return [
    `browser    session created · guard ALLOW`,
    `fetch      ${host} · dry-run, no live socket`,
    "extract    title, headings, outbound links",
    "event      BrowserSessionCreated → knowledge pipeline stage 1",
    "done       7-stage pipeline would publish from here when the backend is attached",
  ];
}
