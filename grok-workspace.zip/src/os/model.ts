export const BUDGET_MB = 16384;

export type Profile = "workers" | "ui" | "ollama";
export type ServiceProfile = "core" | Profile;
export type ServiceId =
  | "postgres"
  | "redis"
  | "foundation"
  | "backend"
  | "kernel"
  | "worker"
  | "webui"
  | "ollama";
export type ServiceStatus = "down" | "starting" | "healthy";
export type ViewId =
  | "stack"
  | "command"
  | "link"
  | "memory"
  | "flows"
  | "providers"
  | "govern"
  | "settings";

export type ServiceDef = {
  id: ServiceId;
  name: string;
  port: string;
  mem: number;
  cpu: string;
  role: string;
  profile: ServiceProfile;
};

export const SERVICES: ServiceDef[] = [
  { id: "postgres", name: "PostgreSQL 16", port: "5432", mem: 512, cpu: "1.0", role: "Shared store · assist_os + assist_kernel", profile: "core" },
  { id: "redis", name: "Redis 7", port: "6379", mem: 256, cpu: "0.5", role: "Event bus and durable queue", profile: "core" },
  { id: "foundation", name: "Foundation", port: "8800", mem: 256, cpu: "0.5", role: "OpenAI-compatible assistai server", profile: "core" },
  { id: "backend", name: "Backend API", port: "8000", mem: 512, cpu: "1.0", role: "Hardened 21-router suite", profile: "core" },
  { id: "kernel", name: "Self-Operating Kernel", port: "8001", mem: 512, cpu: "1.0", role: "Policy, tools, OpenAI shim", profile: "core" },
  { id: "worker", name: "Kernel worker", port: "internal", mem: 256, cpu: "0.5", role: "app.workers.runner", profile: "workers" },
  { id: "webui", name: "Open WebUI", port: "3000", mem: 1536, cpu: "1.0", role: "Chat connected to kernel /v1", profile: "ui" },
  { id: "ollama", name: "Ollama", port: "11434", mem: 5120, cpu: "host", role: "qwen2.5-coder local models", profile: "ollama" },
];

export type Provider = {
  id: string;
  name: string;
  model: string;
  quota: string;
  active: boolean;
  local?: boolean;
};

export const PROVIDERS: Provider[] = [
  { id: "ollama", name: "Ollama local", model: "qwen2.5-coder:7b", quota: "Always-on · zero cost", active: true, local: true },
  { id: "groq", name: "Groq", model: "llama-3.3-70b-versatile", quota: "30 RPM · 14.4K TPM", active: false },
  { id: "gemini", name: "Gemini", model: "gemini-2.5-flash", quota: "15 RPM · 1,500 req/day", active: false },
  { id: "cerebras", name: "Cerebras", model: "llama-3.3-70b", quota: "30 RPM · 1M tokens/day", active: false },
  { id: "github", name: "GitHub Models", model: "gpt-4o", quota: "15 RPM developer tier", active: false },
  { id: "nvidia", name: "NVIDIA NIM", model: "llama-3.1-70b-instruct", quota: "Developer credits", active: false },
  { id: "openrouter", name: "OpenRouter", model: "llama-3.2-3b-instruct:free", quota: "200 RPM free models", active: false },
  { id: "mistral", name: "Mistral", model: "codestral-latest", quota: "1 RPS free tier", active: false },
  { id: "cohere", name: "Cohere", model: "command-r-plus", quota: "Trial key", active: false },
  { id: "cloudflare", name: "Cloudflare Workers AI", model: "llama-3.1-8b", quota: "10,000 neurons/day", active: false },
  { id: "huggingface", name: "Hugging Face", model: "Qwen2.5-72B-Instruct", quota: "Serverless inference", active: false },
  { id: "llm7", name: "LLM7 gateway", model: "multi-model", quota: "No-card free endpoints", active: false },
];

export type MemoryNote = {
  id: string;
  title: string;
  body: string;
  collection: string;
  tags: string;
};

export const SEED_MEMORIES: MemoryNote[] = [
  {
    id: "mem-foundation",
    title: "Foundation routing",
    body: "Nothing above ModelRouter talks to a backend directly. Default is Ollama at :11434, model qwen2.5-coder:7b, with an optional OpenAI-compatible fallback.",
    collection: "foundation",
    tags: "router ollama memory.json",
  },
  {
    id: "mem-guard",
    title: "ExecutionGuard",
    body: "Every agent action is Agent → ExecutionGuard → BrowserOS. Governance is never bypassed. POST /governance/check uses the JWT role, not the role in the body.",
    collection: "sprint-a",
    tags: "governance event-bus",
  },
  {
    id: "mem-terminal",
    title: "Terminal allowlist",
    body: "Workflow terminal is admin-only and limited to ls, pwd, echo, df, free, ps, uptime, whoami, uname. Path traversal and absolute paths outside the root are blocked.",
    collection: "security",
    tags: "rbac vault",
  },
  {
    id: "mem-budget",
    title: "16 GB workstation budget",
    body: "Core stack is PostgreSQL 512M, Redis 256M, Foundation 256M, Backend 512M, Kernel 512M. Optional profiles: workers 256M, Open WebUI 1536M, Ollama 5G.",
    collection: "ops",
    tags: "compose memory",
  },
  {
    id: "mem-vault",
    title: "Sealed vault",
    body: "SecretVault stores v1:nonce:ciphertext:tag using PBKDF2-HMAC-SHA256, a random nonce, and an HMAC. Vault and audit routes require an admin.",
    collection: "security",
    tags: "vault hmac",
  },
];

export type ChatMessage = {
  id: string;
  role: "operator" | "kernel";
  text: string;
  provider?: string;
  verdict?: "ALLOW" | "DENY";
  cites?: string[];
};

export type BusEvent = {
  id: string;
  ts: string;
  type: string;
  src: string;
  detail: string;
};

export type Decision = {
  id: string;
  agent: string;
  summary: string;
  ts: string;
};

export type Job = {
  id: string;
  name: string;
  status: "running" | "done" | "denied";
  lines: string[];
};

export type Settings = {
  operator: string;
  model: string;
  remediation: boolean;
};

export const COLLECTIONS = ["foundation", "sprint-a", "security", "ops", "lab"] as const;

export function selectedServices(profiles: Record<Profile, boolean>) {
  return SERVICES.filter((service) => {
    if (service.profile === "core") return true;
    return profiles[service.profile];
  });
}

export function budgetOf(ids: ServiceId[]) {
  return SERVICES.filter((service) => ids.includes(service.id)).reduce((sum, service) => sum + service.mem, 0);
}

export function bestProvider(providers: Provider[]) {
  return providers.find((provider) => provider.active) ?? null;
}

export function stamp(date = new Date()) {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
