import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  BUDGET_MB,
  PROVIDERS,
  SEED_MEMORIES,
  SERVICES,
  bestProvider,
  budgetOf,
  selectedServices,
  stamp,
  uid,
  type BusEvent,
  type ChatMessage,
  type Decision,
  type Job,
  type MemoryNote,
  type Profile,
  type Provider,
  type ServiceId,
  type ServiceStatus,
  type Settings,
  type ViewId,
} from "@/os/model";
import { composeAnswer, govern, runDiagnostic, scrapeScript, supervisorScript } from "@/os/kernel";

type StatusMap = Record<ServiceId, ServiceStatus>;

const downStatus = (): StatusMap =>
  Object.fromEntries(SERVICES.map((service) => [service.id, "down"])) as StatusMap;

const timers = new Set<number>();

function clearTimers() {
  timers.forEach((id) => window.clearTimeout(id));
  timers.clear();
}

function later(fn: () => void, ms: number) {
  const id = window.setTimeout(() => {
    timers.delete(id);
    fn();
  }, ms);
  timers.add(id);
}

function pushLog(logs: string[], line: string) {
  return [...logs, `${stamp()}  ${line}`].slice(-80);
}

function pushEvent(events: BusEvent[], event: Omit<BusEvent, "id" | "ts">): BusEvent[] {
  return [{ id: uid("ev"), ts: stamp(), ...event }, ...events].slice(0, 40);
}

type OsState = {
  view: ViewId;
  moreOpen: boolean;
  profiles: Record<Profile, boolean>;
  status: StatusMap;
  logs: string[];
  notice: string | null;
  providers: Provider[];
  messages: ChatMessage[];
  drafting: boolean;
  memories: MemoryNote[];
  events: BusEvent[];
  decisions: Decision[];
  jobs: Job[];
  settings: Settings;
  setView: (view: ViewId) => void;
  setMore: (open: boolean) => void;
  toggleProfile: (profile: Profile) => void;
  bringUp: () => void;
  halt: () => void;
  toggleProvider: (id: string) => void;
  send: (text: string) => void;
  addMemory: (note: Omit<MemoryNote, "id">) => void;
  removeMemory: (id: string) => void;
  runSupervisor: (goal: string) => void;
  runScrape: (url: string) => void;
  runTerminal: (command: string) => void;
  checkGovernance: (action: string) => GovernFlash | null;
  governFlash: GovernFlash | null;
  patchSettings: (patch: Partial<Settings>) => void;
  resetWorkstation: () => void;
};

export type GovernFlash = { verdict: "ALLOW" | "DENY"; reason: string; action: string };

const seedDecisions = (): Decision[] => [
  {
    id: "dec-budget",
    agent: "ArchitectureAuditor",
    summary: "Locked the always-on set to the 2 GB core so a 16 GB workstation can still host Ollama.",
    ts: "boot",
  },
  {
    id: "dec-router",
    agent: "ModelRouter",
    summary: "Armed Ollama first. Cloud providers stay dark until an operator toggles them.",
    ts: "boot",
  },
];

const initial = () => ({
  view: "stack" as ViewId,
  moreOpen: false,
  profiles: { workers: false, ui: false, ollama: true },
  status: downStatus(),
  logs: ["console attached · stack halted · profiles remembered"],
  notice: null as string | null,
  providers: PROVIDERS,
  messages: [] as ChatMessage[],
  drafting: false,
  memories: SEED_MEMORIES,
  events: [] as BusEvent[],
  decisions: seedDecisions(),
  jobs: [] as Job[],
  settings: { operator: "operator", model: "qwen2.5-coder:7b", remediation: false },
  governFlash: null as GovernFlash | null,
});

export const useOs = create<OsState>()(
  persist(
    (set, get) => ({
      ...initial(),
      setView: (view) => set({ view, moreOpen: false }),
      setMore: (moreOpen) => set({ moreOpen }),
      toggleProfile: (profile) =>
        set((state) => ({
          profiles: { ...state.profiles, [profile]: !state.profiles[profile] },
          notice: "Profile saved. It applies the next time you bring the stack up.",
        })),
      bringUp: () => {
        clearTimers();
        const profiles = get().profiles;
        const chosen = selectedServices(profiles);
        const mem = chosen.reduce((sum, service) => sum + service.mem, 0);
        if (mem > BUDGET_MB) {
          set({ notice: `Refused. ${mem} MB is over the ${BUDGET_MB} MB workstation ceiling.` });
          return;
        }
        const status = downStatus();
        chosen.forEach((service) => {
          status[service.id] = "starting";
        });
        set((state) => ({
          status,
          notice: null,
          logs: pushLog(state.logs, `compose up · ${chosen.map((service) => service.id).join(", ")} · ${mem} MB`),
          events: pushEvent(state.events, {
            type: "SYSTEM_HEALTH_CHANGED",
            src: "compose",
            detail: `starting ${chosen.length} services`,
          }),
        }));
        chosen.forEach((service, index) => {
          later(() => {
            set((state) => ({
              status: { ...state.status, [service.id]: "healthy" },
              logs: pushLog(state.logs, `${service.name} healthy · :${service.port}`),
              events: pushEvent(state.events, {
                type: "SYSTEM_HEALTH_CHANGED",
                src: service.id,
                detail: `${service.name} ready`,
              }),
            }));
          }, 280 + index * 320);
        });
      },
      halt: () => {
        clearTimers();
        set((state) => ({
          status: downStatus(),
          notice: null,
          logs: pushLog(state.logs, "compose down · volumes kept"),
          events: pushEvent(state.events, {
            type: "SYSTEM_HEALTH_CHANGED",
            src: "compose",
            detail: "stack halted",
          }),
        }));
      },
      toggleProvider: (id) =>
        set((state) => {
          const providers = state.providers.map((provider) =>
            provider.id === id ? { ...provider, active: !provider.active } : provider,
          );
          const best = bestProvider(providers);
          return {
            providers,
            notice: `best_provider → ${best ? best.id : "none"}`,
            events: pushEvent(state.events, {
              type: "PROVIDER_SET_CHANGED",
              src: "registry",
              detail: best ? `${best.id} is first armed` : "no provider armed",
            }),
          };
        }),
      send: (text) => {
        const trimmed = text.trim();
        if (!trimmed || get().drafting) return;
        const foundation = get().status.foundation;
        const operator: ChatMessage = { id: uid("op"), role: "operator", text: trimmed };
        if (foundation !== "healthy") {
          const kernel: ChatMessage = {
            id: uid("k"),
            role: "kernel",
            text: "Foundation is not healthy. Bring the core stack up on the Stack desk, then ask again. Port 8800 is the OpenAI-compatible front door.",
            verdict: "DENY",
          };
          set((state) => ({ messages: [...state.messages, operator, kernel].slice(-40) }));
          return;
        }
        set((state) => ({ messages: [...state.messages, operator].slice(-40), drafting: true }));
        const answer = composeAnswer(trimmed, get().memories, get().providers, get().settings.model);
        later(() => {
          const kernel: ChatMessage = {
            id: uid("k"),
            role: "kernel",
            text: answer.text,
            provider: answer.provider,
            verdict: answer.verdict,
            cites: answer.cites,
          };
          const decision: Decision = {
            id: uid("dec"),
            agent: answer.verdict === "DENY" ? "ExecutionGuard" : "ModelRouter",
            summary: answer.verdict === "DENY" ? answer.reason : `Answered via ${answer.provider}. ${answer.reason}`,
            ts: stamp(),
          };
          set((state) => ({
            drafting: false,
            messages: [...state.messages, kernel].slice(-40),
            decisions: [decision, ...state.decisions].slice(0, 24),
            events: pushEvent(state.events, {
              type: answer.verdict === "DENY" ? "ACTION_DENIED" : "AGENT_TASK_COMPLETED",
              src: "kernel",
              detail: answer.verdict === "DENY" ? answer.reason : `provider ${answer.provider}`,
            }),
          }));
        }, 420);
      },
      addMemory: (note) =>
        set((state) => ({
          memories: [{ ...note, id: uid("mem") }, ...state.memories],
          events: pushEvent(state.events, {
            type: "MEMORY_WRITTEN",
            src: "memory",
            detail: note.title,
          }),
        })),
      removeMemory: (id) => set((state) => ({ memories: state.memories.filter((note) => note.id !== id) })),
      runSupervisor: (goal) => {
        const clean = goal.trim();
        if (!clean) return;
        if (get().status.backend !== "healthy") {
          set({ notice: "Backend :8000 is down. Workflows mount on the API suite." });
          return;
        }
        const job: Job = { id: uid("job"), name: "supervisor", status: "running", lines: [] };
        set((state) => ({ jobs: [job, ...state.jobs].slice(0, 12), notice: null }));
        supervisorScript(clean).forEach((line, index) => {
          later(() => {
            set((state) => ({
              jobs: state.jobs.map((item) =>
                item.id === job.id
                  ? {
                      ...item,
                      lines: [...item.lines, line],
                      status: index === supervisorScript(clean).length - 1 ? "done" : "running",
                    }
                  : item,
              ),
            }));
          }, 240 + index * 280);
        });
      },
      runScrape: (url) => {
        const clean = url.trim();
        if (get().status.backend !== "healthy") {
          set({ notice: "Backend :8000 is down. The browser adapter lives there." });
          return;
        }
        const gate = govern(`browse ${clean}`);
        const lines = gate.verdict === "DENY" ? [`DENY  ${gate.reason}`] : scrapeScript(clean || "https://example.com");
        const job: Job = {
          id: uid("job"),
          name: "scrape",
          status: gate.verdict === "DENY" ? "denied" : "running",
          lines: [],
        };
        set((state) => ({ jobs: [job, ...state.jobs].slice(0, 12) }));
        lines.forEach((line, index) => {
          later(() => {
            set((state) => ({
              jobs: state.jobs.map((item) =>
                item.id === job.id
                  ? { ...item, lines: [...item.lines, line], status: index === lines.length - 1 ? (gate.verdict === "DENY" ? "denied" : "done") : item.status }
                  : item,
              ),
            }));
          }, 200 + index * 240);
        });
      },
      runTerminal: (command) => {
        if (get().status.kernel !== "healthy") {
          set({ notice: "Kernel :8001 is down. The terminal adapter is on the self-operating kernel." });
          return;
        }
        const result = runDiagnostic(command);
        const job: Job = {
          id: uid("job"),
          name: "terminal",
          status: result.ok ? "done" : "denied",
          lines: [`$ ${command.trim()}`, ...result.lines],
        };
        set((state) => ({
          jobs: [job, ...state.jobs].slice(0, 12),
          decisions: [
            {
              id: uid("dec"),
              agent: "TerminalExecutor",
              summary: result.ok ? `Allowlisted ${command.trim()}` : `Blocked ${command.trim()}`,
              ts: stamp(),
            },
            ...state.decisions,
          ].slice(0, 24),
        }));
      },
      governFlash: null,
      checkGovernance: (action) => {
        const clean = action.trim();
        if (!clean) return null;
        const gate = govern(clean);
        const flash = { ...gate, action: clean };
        set((state) => ({
          governFlash: flash,
          decisions: [
            { id: uid("dec"), agent: "ExecutionGuard", summary: `${gate.verdict} · ${clean}`, ts: stamp() },
            ...state.decisions,
          ].slice(0, 24),
          events: pushEvent(state.events, {
            type: gate.verdict === "ALLOW" ? "GOVERNANCE_ALLOW" : "ACTION_DENIED",
            src: "governance",
            detail: clean,
          }),
        }));
        return flash;
      },
      patchSettings: (patch) => set((state) => ({ settings: { ...state.settings, ...patch } })),
      resetWorkstation: () => {
        clearTimers();
        set({ ...initial(), notice: "Workstation reset. Stack is halted." });
      },
    }),
    {
      name: "assist-os-v62",
      skipHydration: true,
      partialize: (state) => ({
        view: state.view,
        profiles: state.profiles,
        status: state.status,
        logs: state.logs,
        providers: state.providers,
        messages: state.messages,
        memories: state.memories,
        events: state.events,
        decisions: state.decisions,
        jobs: state.jobs,
        settings: state.settings,
      }),
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        const status = { ...state.status };
        (Object.keys(status) as ServiceId[]).forEach((id) => {
          if (status[id] === "starting") status[id] = "healthy";
        });
        state.status = status;
      },
    },
  ),
);

export function useHealthyCount() {
  return useOs((state) => Object.values(state.status).filter((status) => status === "healthy").length);
}

export function useLiveBudget() {
  const status = useOs((state) => state.status);
  const ids = (Object.keys(status) as ServiceId[]).filter((id) => status[id] !== "down");
  return budgetOf(ids);
}
