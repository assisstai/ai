import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Console } from "@/components/os/console";
import { useOs } from "@/os/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  useEffect(() => {
    void useOs.persist.rehydrate();
  }, []);
  return <Console />;
}
